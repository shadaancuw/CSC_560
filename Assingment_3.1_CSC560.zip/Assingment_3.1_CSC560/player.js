const mongoose = require('mongoose');

const playerSchema = new mongoose.Schema({
  //  schema fields here
  name: String,
  age: Number,
});

const PlayerModel = mongoose.model('Player', playerSchema);

module.exports = PlayerModel;
