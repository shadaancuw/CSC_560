const app = require('./server');
const { deleteMany, create } = require('./player');
const chai = require('chai');
const chaiHttp = require('chai-http');
const request = require('supertest');
const PlayerModel = require('./player');
chai.use(chaiHttp);



describe('Player API', () => {
  
    before(async () => {
      await PlayerModel.deleteMany({});
  });

  afterEach((done) => {
    deleteMany({}, () => {
      done();
    });
  });

  describe('POST /players', () => {
    it('should create a new player', (done) => {
      request(app)
        .post('/players')
        .send({ name: 'John Doe', position: 'Forward' })
        .end((err, res) => {
          expect(res).to.have.status(201);
          expect(res.body).to.be.an('object');
          expect(res.body).to.have.property('_id');
          expect(res.body.name).to.equal('John Doe');
          expect(res.body.position).to.equal('Forward');
          done();
        });
    });

    it('should return an error if the player data is incomplete', (done) => {
      request(app)
        .post('/players')
        .send({ name: 'John Doe' })
        .end((err, res) => {
          expect(res).to.have.status(500);
          done();
        });
    });
  });

  describe('GET /players', () => {
    it('should retrieve all players', (done) => {
      create({ name: 'John Doe', position: 'Forward' }, () => {
        request(app)
          .get('/players')
          .end((err, res) => {
            expect(res).to.have.status(200);
            expect(res.body).to.be.an('array');
            expect(res.body.length).to.equal(1);
            done();
          });
      });
    });
  });

  describe('PUT /players/:id', () => {
    it('should update a player', (done) => {
      create({ name: 'John Doe', position: 'Forward' }, (err, player) => {
        request(app)
          .put(`/players/${player._id}`)
          .send({ name: 'Updated Player', position: 'Midfielder' })
          .end((err, res) => {
            expect(res).to.have.status(200);
            expect(res.body).to.be.an('object');
            expect(res.body.name).to.equal('Updated Player');
            expect(res.body.position).to.equal('Midfielder');
            done();
          });
      });
    });
  });

  describe('DELETE /players/:id', () => {
    it('should delete a player', (done) => {
      create({ name: 'John Doe', position: 'Forward' }, (err, player) => {
        request(app)
          .delete(`/players/${player._id}`)
          .end((err, res) => {
            expect(res).to.have.status(204);
            done();
          });
      });
    });
  });
});
