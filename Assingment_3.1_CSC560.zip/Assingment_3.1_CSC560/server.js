const express = require('express');
const bodyParser = require('body-parser');
const Player = require('./player');
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Create a player
app.post('/players', (req, res) => {
  const { name, position } = req.body;
  const player = new Player({ name, position });
  player.save((err, savedPlayer) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error saving player');
    } else {
      res.status(201).send(savedPlayer);
    }
  });
});

// Get all players
app.get('/players', (req, res) => {
  Player.find({}, (err, players) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error retrieving players');
    } else {
      res.send(players);
    }
  });
});

// Update a player
app.put('/players/:id', (req, res) => {
  const { id } = req.params;
  const { name, position } = req.body;
  Player.findByIdAndUpdate(id, { name, position }, { new: true }, (err, updatedPlayer) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error updating player');
    } else {
      res.send(updatedPlayer);
    }
  });
});

// Delete a player
app.delete('/players/:id', (req, res) => {
  const { id } = req.params;
  Player.findByIdAndDelete(id, (err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error deleting player');
    } else {
      res.sendStatus(204);
    }
  });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
