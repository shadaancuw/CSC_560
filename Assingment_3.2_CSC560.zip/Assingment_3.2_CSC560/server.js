const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Connect to MongoDB database
mongoose.connect('mongodb://localhost:27017/Players', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

const Player = require('./players');

// GET all players
app.get('/players', (req, res) => {
  Player.find()
    .then(players => res.json(players))
    .catch(err => res.status(404).json({ error: 'No players found' }));
});

// GET player by ID
app.get('/players/:id', (req, res) => {
  Player.findById(req.params.id)
    .then(player => {
      if (player) {
        res.json(player);
      } else {
        res.status(404).json({ error: 'Player not found' });
      }
    })
    .catch(err => res.status(400).json({ error: err.message }));
});

// CREATE new player
app.post('/players', (req, res) => {
  const newPlayer = new Player({
    name: req.body.name,
    position: req.body.position,
    rushing_yards: req.body.rushing_yards,
    touchdowns_thrown: req.body.touchdowns_thrown,
    sacks: req.body.sacks,
    field_goals_made: req.body.field_goals_made,
    field_goals_missed: req.body.field_goals_missed,
    catches_made: req.body.catches_made
  });

  newPlayer.save()
    .then(player => res.json(player))
    .catch(err => res.status(400).json({ error: err.message }));
});

// UPDATE player by ID
app.put('/players/:id', (req, res) => {
  Player.findByIdAndUpdate(req.params.id, req.body, { new: true })
    .then(player => {
      if (player) {
        res.json(player);
      } else {
        res.status(404).json({ error: 'Player not found' });
      }
    })
    .catch(err => res.status(400).json({ error: err.message }));
});

// DELETE player by ID
app.delete('/players/:id', (req, res) => {
  Player.findByIdAndDelete(req.params.id)
    .then(player => {
      if (player) {
        res.json({ success: true });
      } else {
        res.status(404).json({ error: 'Player not found' });
      }
    })
    .catch(err => res.status(400).json({ error: err.message }));
});

app.listen(port, () => console.log(`Server listening on port ${port}`));
