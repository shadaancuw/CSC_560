const MongoClient = require('mongodb').MongoClient;

// Set up database connection
const url = 'mongodb://localhost:27017';

const dbName = 'Players';
let db;

const connect = () => {
  MongoClient.connect(url, { useNewUrlParser: true }, (err, client) => {
    if (err) {
      console.log('Error connecting to MongoDB:', err);
    } else {
      console.log('Connected to MongoDB successfully!');
      db = client.db(dbName);
    }
  });
}

const getDb = () => db;

module.exports = {
  connect,
  getDb,
}
